package fr.gsb.applicrdr.modeles;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.table.AbstractTableModel;

import fr.gsb.applicrdr.entites.Praticien;
import fr.gsb.applicrdr.entites.Rapport;

public class ModeleListePraticien  extends AbstractTableModel {
	
	private Praticien praticien ;
	private String nom ;
	private String ville ;
	private List<Praticien> praticiens = new ArrayList<Praticien>() ;
	private final String[] entetes = {"Nom du praticien", "Ville", "Coef. Confiance", "Dernière visite", "Coef. Notoriété"} ;
	
	public List<Praticien> getPraticiens() {
		return praticiens ;
	}
	
	public void setPraticiens(List<Praticien> praticiens) {
		this.praticiens = praticiens ;
	}
	
	public ModeleListePraticien() {
		super() ;
	}
	
	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		switch(columnIndex) {
			case 0 :
				return this.praticiens.get(rowIndex).getNom() ;
			case 1 : 
				return this.praticiens.get(rowIndex).getVille() ;
			case 2 : 
				return "" + this.praticiens.get(rowIndex).getCoefConf() ;
			case 3 : 
				return "" + this.praticiens.get(rowIndex).getDerniereVisite() ;
			case 4 : 
				return "" + this.praticiens.get(rowIndex).getCoefNot() ;
			default :
				return null ;
		}
	}
	
	public Class columnClass(int columnIndex) {
		switch(columnIndex) {
			case 0 :
				return String.class ;
			case 1 :
				return String.class ;
			case 2 :
				return String.class ;
			case 3 :
				return String.class ;
			case 4 :
				return String.class ;
			default :
				return Object.class ;
		
		}
		
	}
	@Override
	public String getColumnName(int columnIndex) {
		// TODO Auto-generated method stub
		return entetes[columnIndex] ;
	}
	
	

}
