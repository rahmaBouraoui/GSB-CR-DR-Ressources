package fr.gsb.applicrdr.controleurs;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import fr.gsb.applicrdr.vues.VueGsb;
import fr.gsb.applicrdr.vues.VuePraticienHesitant;

public class ControleurListePraticien implements ActionListener {

	private VuePraticienHesitant vuePraticienHesitant ;
	private VueGsb vueGsb ;
	
	public ControleurListePraticien(VuePraticienHesitant vue) {
		super() ;
		this.vuePraticienHesitant = vue ;
		this.enregistrerEcouteur();
	}
	
	private void enregistrerEcouteur() {
		System.out.println("ControleurListePraticien::enregistrerEcouteur()") ;
		this.vuePraticienHesitant.getRbCoefConf().addActionListener(this);
		this.vuePraticienHesitant.getRbTemps().addActionListener(this);
		this.vuePraticienHesitant.getRbCoefNot().addActionListener(this); 
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
